![Zadania z JS](enter-image.svg)

# Zadania z Javascript

Witam serdecznie w zadaniach z Javascript.

W każdym katalogu znajduje się plik **README.md**, w którym znajduje się treść zadań.

Spróbuj się z nimi zmierzyć. Nikt ci tutaj nie narzuca sposobu rozwiązania, kolejności czy używanych narzędzi.

W razie problemów pytaj.

Tyle wstępu. Miłej zabawy :)

