# Zadania - DOM
==========================


## Zadanie 1
--------------------------
Po kliknięciu na przycisk przy samochodzie:
- pokaż element `.car-detail` dla danego samochodu.
- zmień tekst na przycisku na "schowaj detale".
- dodaj klasę `.car-show-detail` do danego samochodu (elementu `.car`)

Po ponownym kliknięciu na przycisk
- Przywróć początkowy tekst na przycisku (pokaż detale)
- schowaj `.car-detail` danego samochodu
- usuń klasę `.car-show-detail` z danego samochodu


## Materiały:
--------------------------
https://kursjs.pl/kurs/dom/dom.php
https://kursjs.pl/kurs/events/events.php
