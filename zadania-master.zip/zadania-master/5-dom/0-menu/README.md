# Zadania - DOM
==========================


## Zadanie 1
--------------------------
Wykonaj następujące czynności:
1. Dodaj mu klasę .menu
2. pierwszemu LI w tym ul dodaj klasę `.first`
3. ostatniemu LI w tym ul dodaj klasę `.last`
4. trzeciemu LI w tym ul ustaw klasę `.active`
5. trzeciemu LI w tym ul ustaw za pomocą JS kolor tekstu na `#fff`
6. każdemu linkowi w tym menu ustaw atrybut `title="Przejdź na stronę ..."` gdzie ... to tekst danego linka
7. za pomocą JS każdemu linkowi w tym ul ustaw atrybut href na #. Po co to robimy? Czy jest alternatywna metoda?
8. Dodaj do każdego linka w ul zdarzenie CLICK. Po kliknięciu powinien pojawić się alert z tekstem, który widnieje na linku (np "Kliknięto Start")
9. Dla linka w `li.active` usuń zdarzenie click (tak by nie pojawiał sie alert po kliknięciu)


## Materiały:
--------------------------
https://kursjs.pl/kurs/dom/dom.php
https://kursjs.pl/kurs/events/events.php