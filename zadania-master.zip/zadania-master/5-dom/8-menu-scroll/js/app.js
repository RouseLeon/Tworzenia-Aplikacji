// Pobieramy wszystkie linki w nawigacji
const navLinks = document.querySelectorAll('nav a');

navLinks.forEach(link => {
    link.addEventListener('click', e => {
        e.preventDefault(); // blokuje domyślne przewijanie strony

        // 1. Przełączamy klasę na li
        const li = link.closest('li'); // szukamy rodzica li
        const activeLi = li.parentElement.querySelector('.nav-li-active');

        if (activeLi) {
            activeLi.classList.remove('nav-li-active');
        }
        li.classList.add('nav-li-active');

        // 2. Przewijamy stronę do sekcji
        const targetId = link.getAttribute('href'); // np. "#section1"
        const targetEl = document.querySelector(targetId);

        if (targetEl) {
            targetEl.scrollIntoView({ behavior: 'smooth' }); // płynne przewijanie
        }
    });
});
