# Zadania - DOM
==========================


## Zadanie 1
--------------------------
Przy wysyłce formularza dodaj do listy nowego użytkownika. Niech formularz nie przeładowuje strony.

Postaraj się nie podpinać zdarzenia click dla `button:submit`, a podpiąć się pod zdarzenie submit dla formularza.

Po kliknięciu na przycisk usuwania (kosz na śmieci) usuń danego użytkownika z listy


## Materiały:
--------------------------
https://kursjs.pl/kurs/dom/dom.php
https://kursjs.pl/kurs/events/events.php
