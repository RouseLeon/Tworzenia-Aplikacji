# Zadania - DOM
==========================


## Zadanie 1
--------------------------
Po kliknięciu w "dodaj element" do listy dodaj nowy element podobny do tego już istniejącego na liście

Po dodaniu powinien mieć kolejny numer który wylicz na podstawie ilości elementów + 1

Po kliknięciu w ikonę kosza usuń dany element
Po kliknięciu w ikonę klonowania sklonuj na koniec listy dany element


## Materiały:
--------------------------
https://kursjs.pl/kurs/dom/dom.php
https://kursjs.pl/kurs/events/events.php
