// 1) Pobranie menu i dodanie klasy
const menu = document.querySelector('#menu');
menu.classList.add('menu');

// 2) Pobranie wszystkich LI i A
const menuItems = menu.querySelectorAll('li');
const menuLinks = menu.querySelectorAll('a');

// 3) Hover: dodanie klasy .active
menuItems.forEach(li => {
    li.addEventListener('mouseenter', () => {
        menuItems.forEach(el => el.classList.remove('active'));
        li.classList.add('active');
    });
});

// 4) Kliknięcie na link
menuLinks.forEach(link => {
    link.addEventListener('click', e => {
        e.preventDefault(); // zatrzymanie domyślnej akcji

        const li = link.closest('li');

        // Wszystkim innym LI dodajemy .collapsed i usuwamy .expand
        menuItems.forEach(el => {
            if (el !== li) {
                el.classList.add('collapsed');
                el.classList.remove('expand');
            }
        });

        // Klikniętemu LI dodajemy .expand i usuwamy .collapsed
        li.classList.add('expand');
        li.classList.remove('collapsed');

        // Podpinamy event transitionend
        li.addEventListener('transitionend', elementTransitionEnd);
    });
});

// Funkcja nazwana dla transitionend
function elementTransitionEnd(event) {
    const li = event.currentTarget;
    li.removeEventListener('transitionend', elementTransitionEnd);

    const link = li.querySelector('a');
    console.log('Kliknięto link:', link.href);

    // Dodatkowy przycisk "Zamknij"
    const closeBtn = document.createElement('button');
    closeBtn.classList.add('close');
    closeBtn.textContent = 'Zamknij';
    li.appendChild(closeBtn);

    closeBtn.addEventListener('click', () => {
        // Usuwamy klasy .expand i .collapsed ze wszystkich LI
        menuItems.forEach(el => {
            el.classList.remove('expand', 'collapsed');
        });
        // Usuwamy przycisk
        closeBtn.remove();
    });
}
