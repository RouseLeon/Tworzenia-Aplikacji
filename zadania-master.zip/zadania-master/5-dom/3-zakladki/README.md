# Zadania - DOM
==========================


## Zadanie 1
--------------------------
Po kliknięciu w link w zakładkach:
- przełącz aktywną zakładkę (zmieniając klasę `tab-el-active`)
- pokaż treść zakładki na którą kieruje dany link, ukryj pozostałe treści


## Materiały:
--------------------------
https://kursjs.pl/kurs/dom/dom.php
https://kursjs.pl/kurs/events/events.php