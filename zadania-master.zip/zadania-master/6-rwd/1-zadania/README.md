# Zadania - RWD
==========================


## Zadanie 1
--------------------------
Na stronie znajduje się nagłówek `.header`.

Napisz kod, który podczas przewijania okna sprawdzi pozycję paska przewijania (pozycję możesz znaleźć w obiekcie `window`, więc wypisz go w konsoli). Jeżeli będzie ona większa niż 100px, niech skrypt doda do nagłówka klasę `.sticky`. Jeżeli pozycja będzie mniejsza niech tą klasę usunie.


## Zadanie 2
--------------------------
Nagłówek ma pozycjonowanie fixed, więc jest przypięty do ekranu. Dla małych ekranów (max 600px szerokości) nagłówek zmienia pozycjonowanie na absolutne, więc powyższy kod nie będzie miał sensu. Dopisz dodatkowy kod, który powyższe dodawanie klasy będzie wykonywał tylko dla ekranów `>= 600px`.


## Materiały:
--------------------------
https://kursjs.pl/kurs/rwd.php
https://kursjs.pl/kurs/events/events.php
