# Zadania - RWD
==========================


## Zadanie 1
--------------------------
Na stronie znajduje się czerwony div.
Na ekranach powyżej `600px` w jego wnętrzu powinien znajdować się tekst z rozmiarami okna np.
`1920x1080`. Rozmiary możesz pobrać z obiektu window. Podczas zmiany rozmiarów okna tekst ten dynamicznie powinien się zmieniać.


## Zadanie 2
--------------------------
Po kliknięciu na div, wymiary okna wypisz w konsoli.

Na małych ekranach (poniżej 600px) div powinien zmienić kolor tła na niebieski, a klikanie na niego nie powinno działać.


## Materiały:
--------------------------
https://kursjs.pl/kurs/rwd.php
https://kursjs.pl/kurs/events/events.php